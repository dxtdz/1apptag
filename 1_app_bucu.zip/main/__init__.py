DBG = True

import requests
import httpx
from rich.console import Console
from typing import cast, Dict, Any
import threading
import hashlib
import base64, zlib, bz2
import paho.mqtt.client as mqtt
import datetime
import json
from urllib.parse import urlparse
import art
import asyncio
import string
import ssl
import certifi
import queue
import io, re, os, sys
import platform, signal
from colorama import Back as B, Style as S
from bs4 import BeautifulSoup
import subprocess, time
import ssl
import random, datetime
import certifi, ab5
from io import BytesIO
import zipfile, pyfiglet

def rgb(r, g, b):
    return f'\033[38;2;{r};{g};{b}m'    

yes=time.time()
class co:
    green = rgb(7, 242, 109)
    gradient1 = [0, 255, 96]
    gradient2 = [7, 242, 137]

    red = rgb(255, 0, 0)
    gred1 = [255, 0, 0]
    gred2 = [43, 2, 2]

    darkred = rgb(69, 12, 12)
    gdarkred1 = [163, 44, 44]
    gdarkred2 = [33, 3, 1]

    blue = rgb(0, 146, 250)
    gblue1 = [0, 146, 250]
    gblue2 = [26, 72, 105]

    darkblue = rgb(5, 105, 171)
    gdarkblue1 = [5, 105, 171]
    gdarkblue2 = [8, 36, 117]

    yellow = rgb(255, 232, 25)
    gyellow1 = [255, 232, 25]
    gyellow2 = [189, 158, 87]

    orange = rgb(255, 158, 3)
    gorange1 = [255, 158, 3]
    gorange2 = [110, 72, 11]

    purple = rgb(127, 0, 245)
    gpurple1 = [127, 0, 245]
    gpurple2 = [34, 1, 64]

    cyan = rgb(0, 245, 233)
    gcyan1 = [0, 245, 233]
    gcyan2 = [15, 66, 133]

    magenta = rgb(245, 0, 241)
    gmagenta1 = [245, 0, 241]
    gmagenta2 = [97, 17, 78]

    white = rgb(255, 255, 255)
    black = rgb(77, 76, 76)